+--------------------------------------------------------------+

 The Glide Open Source Project - 3dfx Glide3x driver for Linux/DRI

+--------------------------------------------------------------+

Version      : 3.10.00.30303

Requirements : Voodoo Banshee,Velocity 100/200,Voodoo3/4/5
               Linux
               Mesa/DRI

Installation : Move /usr/lib/glide* files to a safe location;
               then copy all files from archive into /usr/lib

Web Site     : http://glide.sourceforge.net/

