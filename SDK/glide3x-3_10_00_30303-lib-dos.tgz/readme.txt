+--------------------------------------------------------------+

 The Glide Open Source Project - 3dfx Glide3x driver for DOS/DJGPP

+--------------------------------------------------------------+

Version      : 3.10.00.30303

Requirements : Voodoo Banshee,Velocity 100/200,Voodoo3/4/5
               MSDOS, Microsoft Windows 95/98
               DJGPP 2.04 alpha

Installation : copy libgld3x.a, libgld3i.a and glide3x.dxe into DJDIR/lib

Web Site     : http://glide.sourceforge.net/

